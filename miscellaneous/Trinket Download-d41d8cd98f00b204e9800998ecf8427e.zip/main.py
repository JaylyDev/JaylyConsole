print("Enter a number.")
number1 = float(input())
print("Enter another number.")
number2 = float(input())
print("Enter the 3rd number.")
number3 = float(input())
answer = (number1 + number2 + number3)/3
print(answer)